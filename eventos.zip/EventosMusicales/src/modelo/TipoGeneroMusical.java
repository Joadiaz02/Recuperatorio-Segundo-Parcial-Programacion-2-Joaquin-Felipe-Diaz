package modelo;

public enum TipoGeneroMusical {
    ROCK, JAZZ, POP, ELECTRONICA, CLASICA;
}
