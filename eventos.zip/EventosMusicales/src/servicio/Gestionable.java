
package servicio;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Gestionable<T> {
    void agregar(T elemento);
    
    void eliminar(int indice);
    
    T obtener(int indice);
    
    void limpiar();
    
    void ordenar();
    
    void ordenar(Comparator<T> comparator);
    
    List<T> filtrar(Predicate<T> criterio);
    
    void guardarEnBinario(String path) throws Exception;
    
    void cargarDesdeBinario(String path) throws Exception;
    
    void guardarEnCSV(String path) throws Exception;
    
    void cargarDesdeCSV(String path,Function<String, T> trasnformadora) throws Exception;
    
    void mostrarTodos();
}

