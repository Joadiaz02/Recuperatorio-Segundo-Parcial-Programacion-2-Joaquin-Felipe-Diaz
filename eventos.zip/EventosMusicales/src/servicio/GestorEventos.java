
package servicio;

import java.io.*;
import java.util.ArrayList;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class GestorEventos<T extends Comparable<T> & CSVSerializable> implements Gestionable<T> {
    private List<T> lista;

    public GestorEventos() {
        this.lista = new ArrayList<>();
    }

    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se puede agregar nulos");
        }
        lista.add(item);
        }

    @Override
    public void eliminar(int indice){
        validarIndice(indice);
        lista.remove(indice);
    }

    @Override
    public T obtener(int indice){
        validarIndice(indice);
        return lista.get(indice);
    }
    
     public void validarIndice(int indice){
        if(indice < 0 || indice >= lista.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    @Override
    public void limpiar() {
        lista.clear();
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>)Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        lista.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        if (criterio == null) {
            throw new IllegalArgumentException("No se dio ningun criterio de filtracion");
        }
        List<T> toReturn = new ArrayList<>();
        for(T item: lista){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) throws Exception {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path));
        salida.writeObject(lista);
    }

    @Override
    public void cargarDesdeBinario(String path) throws Exception {
        limpiar();
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path));
        lista.addAll((List<T>)entrada.readObject());
        entrada.close();
    }
    

   
    
    @Override
    public void guardarEnCSV(String path) throws Exception {
        File archivo = new File(path);
        BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
            bw.write(lista.get(0).toHeaderCSV());
            for(T n: lista){
                bw.write(n.toCSV()+"\n");
            }
            bw.close();
    }

    
    
    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws Exception {
        limpiar();
        BufferedReader br = new BufferedReader(new FileReader(path));
            String linea = br.readLine(); 
            while ((linea = br.readLine()) != null) {
               lista.add(transformadora.apply(linea));    
            }
        
    }
    
    
    

    @Override
    public void mostrarTodos() {
        lista.forEach(System.out::println);
    }
}
