
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AppConfig {
    public static final Path PATH_FILES = Paths.get("src/data/");
    public static final Path PATH_CSV = PATH_FILES.resolve("eventos-en-csv.csv");
    public static final Path PATH_SER = PATH_FILES.resolve("eventos-serializados.bin");
}

